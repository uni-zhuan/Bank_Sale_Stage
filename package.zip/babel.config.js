// 配置文件，用于兼容更多浏览器
module.exports = {
  presets: [
    '@vue/app'
  ]
}
